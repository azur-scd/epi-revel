omeka-plugin-CollectionThemes
=============================
Omeka plugin to set the theme to use for an individual collection.

## Installing Releases
Released versions of this plugin are [available for download](https://github.com/BGSU-LITS/omeka-plugin-CollectionThemes/releases). You may extract the archive to your Omeka plugin directory. [Installing the plugin in Omeka.](http://omeka.org/codex/Managing_Plugins_2.0)

## Installing Source Code
You will need to place the source code within a directory named CollectionThemes in your Omeka plugin directory.

## Development
This plugin was developed by the [Bowling Green State University Libraries](http://www.bgsu.edu/library.html). Development is [hosted on GitHub](https://github.com/BGSU-LITS/omeka-plugin-CollectionThemes).
