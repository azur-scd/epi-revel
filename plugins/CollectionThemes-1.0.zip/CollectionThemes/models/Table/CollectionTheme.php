<?php
/**
 * Omeka Collection Themes Plugin: Collection Theme Table
 *
 * @author John Kloor <kloor@bgsu.edu>
 * @copyright 2015 Bowling Green State University Libraries
 * @license MIT
 */

/**
 * Omeka Collection Themes Plugin: Collection Theme Table Class
 *
 * @package CollectionThemes
 */
class Table_CollectionTheme extends Omeka_Db_Table
{
}
