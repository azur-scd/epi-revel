<div class="public-featured panel">
    <p>
        <span class="label"><?php echo __('Theme'); ?>:</span>
        <?php echo $themes[$theme]; ?>
    </p>
</div>
