Folder where to create the folder "uv", in which to unzip the files of the
[UniversalViewer] (https://github.com/UniversalViewer/universalviewer/releases).
